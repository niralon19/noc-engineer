---
name: incident-investigation
description: Perform structured evidence-based incident investigation and RCA.
---
# Incident Investigation
1. Establish incident identity, target, severity, start time and time window.
2. Build a timeline from alerts, metrics, logs, configuration and deployment evidence.
3. Maintain competing hypotheses with evidence for and against.
4. Use previous incidents as context, never proof.
5. Assign CONFIRMED, HIGH_CONFIDENCE, INVESTIGATION_INCOMPLETE or INCONCLUSIVE.
6. Record evidence references, missing data, recommendations and verification criteria.
7. Do not execute remediation autonomously.
