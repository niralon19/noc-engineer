---
name: sre-observability
description: Investigate service health and performance using verified metrics and logs.
---
# SRE & Observability
1. Establish entity, symptom, impact and time range.
2. Use only discovered MCP tools and verified schemas.
3. Query narrow metric families; compare against a defined baseline.
4. Account for units, aggregation, scrape interval, freshness and missing samples.
5. Correlate with ECK logs and configuration/deployment changes when available.
6. Preserve source, query, time range and timestamps. Do not infer causation from correlation.
