---
name: devops-operations
description: Investigate deployments, hosts, containers, workloads and services safely.
---
# DevOps & Operations
1. Identify host, workload, environment, service and time window.
2. Inspect current health and recent deployment/configuration history with read-only tools.
3. Correlate rollout timing with metrics and ECK logs.
4. Separate observed runtime state from desired configuration.
5. Do not restart, scale, rollback, deploy or modify resources without explicit approval and server-side authorization.
