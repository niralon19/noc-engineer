---
name: data-quality-integrity
description: Validate completeness, freshness, consistency and correctness of operational data.
---
# Data Quality & Integrity
1. Identify source, schema, expected freshness and reporting window.
2. Check missing values, duplicates, invalid formats, timestamp skew and cardinality changes.
3. Compare sources only when timestamps, units and entity identity align.
4. Distinguish telemetry failure from service failure.
5. Report method, coverage, failure counts and data limitations.
