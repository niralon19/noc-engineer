---
name: data-enrichment-quality
description: Validate enrichment such as IP ranges, ASN, provider and inventory mappings.
---
# Data Enrichment Quality
1. Identify source record and fields requiring enrichment.
2. Validate IP/CIDR, ASN, provider, location and inventory against authoritative sources.
3. Check prefix containment, address family, effective time and freshness.
4. Preserve provenance and conflicting candidates.
5. Report confidence and unresolved mappings; never fabricate provider identity.
