---
name: itsm-coordination
description: Coordinate Jira issues, incident lifecycle, SLA tracking and follow-up.
---
# ITSM & Coordination
1. Use verified Jira tools and configured project/workflow identifiers only.
2. Search for an existing matching issue before proposing a new one.
3. Keep facts, impact, timeline, cause confidence and next actions distinct.
4. Never invent assignees, priorities, SLA targets or transitions.
5. Create/update issues only when explicitly requested or workflow-authorized.
6. Use stable event/incident correlation identifiers to prevent duplicates.
