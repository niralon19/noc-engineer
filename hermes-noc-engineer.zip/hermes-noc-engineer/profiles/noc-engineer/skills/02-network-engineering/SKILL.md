---
name: network-engineering
description: Investigate DNS, IPAM, routing, provider, firewall and connectivity symptoms.
---
# Network Engineering
1. Identify source/destination, protocol, port, direction and time range.
2. Use only verified network MCP tools.
3. Validate DNS, IP/CIDR, ASN/provider, routing, firewall and reachability evidence.
4. Correlate network observations with service metrics and logs.
5. Distinguish observed data-plane behavior from configuration state.
6. Never change firewall/routing configuration; recommend and request approval.
