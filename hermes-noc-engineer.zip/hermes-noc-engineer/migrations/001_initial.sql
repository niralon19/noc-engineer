CREATE TABLE IF NOT EXISTS detection_events (
 event_id TEXT PRIMARY KEY, rule_id TEXT NOT NULL, metric TEXT NOT NULL, entity TEXT NOT NULL,
 observed_value DOUBLE PRECISION NOT NULL, threshold DOUBLE PRECISION NOT NULL, severity TEXT NOT NULL,
 detected_at TIMESTAMPTZ NOT NULL, labels JSONB NOT NULL DEFAULT '{}'::jsonb,
 source TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_detection_events_time ON detection_events(detected_at DESC);
CREATE INDEX IF NOT EXISTS idx_detection_events_entity ON detection_events(entity, detected_at DESC);
CREATE TABLE IF NOT EXISTS investigations (
 investigation_id UUID PRIMARY KEY, correlation_id TEXT NOT NULL, status TEXT NOT NULL,
 summary TEXT, root_cause TEXT, confidence DOUBLE PRECISION, evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
 missing_data JSONB NOT NULL DEFAULT '[]'::jsonb, started_at TIMESTAMPTZ NOT NULL, completed_at TIMESTAMPTZ
);
