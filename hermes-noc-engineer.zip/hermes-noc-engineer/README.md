# Hermes NOC Engineer

On-prem NOC assistant built around an existing Hermes Agent and an existing internal MCP server. This repository does **not** implement a second MCP server.

## Runtime boundaries
- Hermes profile: identity, MCP connection, seven Skills and agent Cron jobs.
- Existing MCP: Grafana/Prometheus, ECK, internal configuration and internal services.
- Python Detection Engine: continuous deterministic detection; no LLM call per metric.
- PostgreSQL: event/incident/investigation state and evidence references; raw metrics/logs stay in source systems.
- RabbitMQ: asynchronous event transport.
- Jira: webhook/polling integration boundary; real project/workflow details must be supplied.

## Layout
`profiles/noc-engineer/` is a portable Hermes profile source. Install it into the actual profile home created by Hermes; do not overwrite an existing `config.yaml`. Python services are under `src/noc_engineer/`.

## Local development
Requires Python 3.11+ and Docker Compose:
```bash
cp .env.example .env
docker compose -f deploy/docker-compose.yml up -d
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```
Compose starts only PostgreSQL and RabbitMQ. It does not deploy Hermes, Prometheus, ECK, Jira or the existing MCP server.

## Not yet implemented
Real MCP/metrics adapter, continuous collection scheduler, durable RabbitMQ consumer/retry/DLQ, PostgreSQL repository implementation, Jira API/webhook adapter, Hermes event bridge, statistical baselines, HA and production secrets integration. These require actual private contracts and are not guessed.

## Hermes docs
- https://hermes-agent.nousresearch.com/docs/user-guide/profiles
- https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp
- https://hermes-agent.nousresearch.com/docs/reference/mcp-config-reference
- https://hermes-agent.nousresearch.com/docs/user-guide/features/skills
- https://hermes-agent.nousresearch.com/docs/user-guide/features/cron

## Security
The target GitHub repository was public when inspected. Make it private before adding internal hostnames, IPs, topology, MCP tool schemas, runbooks, real logs/alerts or credentials. This scaffold contains generic templates only.
