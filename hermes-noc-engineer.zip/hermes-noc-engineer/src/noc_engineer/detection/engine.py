from hashlib import sha256
from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel

class Severity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"

class MetricSample(BaseModel):
    metric: str
    entity: str
    value: float
    observed_at: datetime
    labels: dict[str, str] = {}

class DetectionRule(BaseModel):
    rule_id: str
    metric: str
    operator: str
    threshold: float
    severity: Severity
    description: str

class DetectionEvent(BaseModel):
    event_id: str
    rule_id: str
    metric: str
    entity: str
    observed_value: float
    threshold: float
    severity: Severity
    detected_at: datetime
    description: str
    labels: dict[str, str]

_OPS = {"gt": lambda x,t: x>t, "gte": lambda x,t: x>=t, "lt": lambda x,t: x<t, "lte": lambda x,t: x<=t}

def evaluate(sample: MetricSample, rule: DetectionRule) -> DetectionEvent | None:
    if sample.metric != rule.metric:
        return None
    if rule.operator not in _OPS:
        raise ValueError(f"Unsupported operator: {rule.operator}")
    if not _OPS[rule.operator](sample.value, rule.threshold):
        return None
    key = "|".join((rule.rule_id, sample.metric, sample.entity, sample.observed_at.isoformat()))
    return DetectionEvent(event_id=sha256(key.encode()).hexdigest()[:24], rule_id=rule.rule_id, metric=sample.metric, entity=sample.entity, observed_value=sample.value, threshold=rule.threshold, severity=rule.severity, detected_at=sample.observed_at, description=rule.description, labels=sample.labels)
