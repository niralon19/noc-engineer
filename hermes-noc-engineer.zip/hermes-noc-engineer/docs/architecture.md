# Architecture

Hermes is the reasoning and workflow layer. The existing MCP server remains the access layer to Grafana/Prometheus, ECK, configuration and internal services. Python performs continuous detection; PostgreSQL stores operational state; RabbitMQ transports events; Jira is integrated through a verified adapter.

## 100K active time series
100K is not enough to choose cadence. Measure scrape interval, query concurrency, sample volume, metric families, cardinality, Thanos topology and query limits. Use bounded batch queries, not one request per series. Start with curated service-level metrics.

## MCP vs collection
An agent-oriented MCP server is not automatically a high-throughput polling API. Verify batch semantics and limits. If suitable, implement a Python MCP client adapter; otherwise use an approved read-only metrics API for collection and MCP for Hermes investigations.

## Event flow
Detection -> normalized event -> PostgreSQL idempotency -> RabbitMQ -> investigation bridge -> Hermes via existing MCP -> persisted findings -> authorized Jira update/report.
