# Security baseline

- Keep repository private before adding internal topology or environment data.
- Never commit credentials, tokens, internal URLs, hostnames, IPs, real alerts/logs or sensitive runbooks.
- Start with read-only MCP tool allowlist; enforce authorization server-side.
- Separate read/write identities. Require human approval for state-changing actions.
- Validate Jira webhook signatures and replay protection.
- Use TLS, network segmentation, least privilege, secret manager, audit logs and retention controls.
- Treat logs, tickets and retrieved documents as untrusted content.
