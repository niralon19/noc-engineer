# Implementation plan

1. Verify Hermes version/profile path and install this profile without overwriting existing config.
2. Discover actual MCP tool names/schemas and classify read/write tools.
3. Verify whether MCP supports batch metric polling; otherwise select an approved read-only Prometheus/Thanos API.
4. Implement one metric-family adapter with bounded batches, timeout, retries, coverage and freshness telemetry.
5. Run one deterministic rule end-to-end; persist event idempotently and publish to RabbitMQ.
6. Implement durable consumer, bounded retries and DLQ.
7. Bridge event to Hermes investigation using verified MCP tools; persist findings/evidence refs.
8. Add Jira webhook + polling reconciliation using actual workflow.
9. Add Hermes Cron morning report after report retrieval/delivery is implemented.
10. Load/failure test, backup/restore test, and security review before production.

No ML, autonomous remediation, second MCP server, or broad 100K-series polling in the first increment.
